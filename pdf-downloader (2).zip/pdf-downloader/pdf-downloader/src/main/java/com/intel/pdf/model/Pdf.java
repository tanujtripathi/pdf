package com.intel.pdf.model;


public class Pdf {

    private String name;

    public Pdf(){

    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Pdf(String name) {
        this.name = name;
    }
}
