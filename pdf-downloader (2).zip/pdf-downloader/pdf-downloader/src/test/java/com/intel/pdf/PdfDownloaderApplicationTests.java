package com.intel.pdf;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PdfDownloaderApplicationTests {

	@Test
	void contextLoads() {
	}

}
